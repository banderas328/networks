### _If you have a feature suggestion, please add it on the [Feature List](https://wysiwyg-editor-roadmap.froala.com/public) instead._

##### Expected behavior.
(Describe expected behaviour here)

##### Actual behavior.
(Describe actual behaviour here)

##### Steps to reproduce the problem.
(Describe the steps to reproduce the problem here. A [jsFiddle](https://jsfiddle.net/froala/cgu0dmxh/) is awesome when possible.)

##### Editor version.
If you don't know it, please see https://wysiwyg-editor.froala.help/hc/en-us/articles/360000717049-How-can-I-find-my-editor-version-.

##### OS.
(OS name and version here)

##### Browser.
(Browser name an version here)

##### Recording.
(A recording showing how to reproduce the problem)
